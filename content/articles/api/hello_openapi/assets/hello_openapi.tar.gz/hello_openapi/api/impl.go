package api

import (
	"encoding/json"
	"log"
	"net/http"
)

type Server struct{}

var data = Status{
	State:   "",
	Message: "",
}

func NewServer() Server {
	data.Message = "Initializing"
	data.State = "Unknown"
	return Server{}
}

func (Server) GetStatus(w http.ResponseWriter, r *http.Request) {
	resp := data

	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(resp)
}

func (Server) PostStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		http.Error(w, "Invalid JSON Format", http.StatusBadRequest)
	}
	log.Printf("State is: %s, Message is: %s\n", data.State, data.Message)

	w.WriteHeader(http.StatusOK)
}

func (Server) GetSpec(w http.ResponseWriter, r *http.Request) {
	spec, _ := GetSwagger()
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(spec)
}

from my_contrived_server_client import AuthenticatedClient
from my_contrived_server_client.api.default import get_status, post_status
from my_contrived_server_client.api.meta import get_spec
from my_contrived_server_client.models import Status

client = AuthenticatedClient(
    base_url="http://127.0.0.1:8080",
    headers={"Content-Type": "application/json", "Accept": "application/json"},
    token="YWxpY2U6bXlTZWNyZXRQVw==",  # Token string is a base64 string containing alice:mySecretPW
    prefix="Basic"
)

with client as client:
    # Show current status
    status = get_status.sync(client=client)
    print(f"Response: {status.to_dict()}")

    # Change/Update status
    data = Status(state="GOOD", message="Running")
    detailedStatus = post_status.sync_detailed(client=client, body=data)
    print(f"HTTP Response Code: {detailedStatus.status_code}")

    # Show new status
    status = get_status.sync(client=client)
    print(f"Response: {status.to_dict()}")

    # Download OpenAPI spec and print
    detailedSpec = get_spec.sync_detailed(client=client)
    print(f"Spec Response:\n{detailedSpec.content.decode('utf-8')}".strip())


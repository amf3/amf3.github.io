package main

import (
	"helloOpenAPI/api"
	"log"
	"net/http"
)

func main() {
	serverAddress := "127.0.0.1:8080"
	server := api.NewServer()
	mux := http.NewServeMux()

	// get an `http.Handler` that we can use
	handler := api.HandlerFromMux(server, mux)
	secured := basicAuthMiddleware("alice", "mySecretPW")(handler)
	loggedHandler := loggingMiddleware(secured)

	s := &http.Server{
		Handler: loggedHandler,
		Addr:    serverAddress,
	}

	// And we serve HTTP until the world ends.
	log.Print("Starting server on: ", serverAddress)
	log.Fatal(s.ListenAndServe())
}
